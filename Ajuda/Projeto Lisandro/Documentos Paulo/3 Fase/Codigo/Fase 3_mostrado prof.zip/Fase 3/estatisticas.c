Estatisticas: 

|-------------------------------------------------------| 
|-------------------------------------------------------| 
|----------- Clientes Atendidos no Bar -----------------| 
|-------------------------------------------------------| 
|-------------------------------------------------------| 

Total Clientes Atendidos Bar: 6 
Total Clientes Mobilidade Reduzida Atendidos Bar: 1 
Total Clientes Crianças Atendidos Bar: 2 
Total Clientes Publico Geral Atendidos Bar: 3 

|-----------------------------------------------------------| 
|-----------------------------------------------------------| 
|-------- Clientes Andaram na Montanha Russa ---------------| 
|-----------------------------------------------------------| 
|-----------------------------------------------------------| 

Total Clientes Andaram Montanha Russa: 2 
Total Clientes Crianças Andaram Montanha Russa: 1 
Total Clientes Publico Geral Andaram Montanha Russa: 1 

|----------------------------------------------------------| 
|----------------------------------------------------------| 
|----------- Clientes Entraram no Carroussel---------------| 
|----------------------------------------------------------| 
|----------------------------------------------------------| 

Total Clientes Entraram Carroussel: 5 
Total Clientes Mobilidade Reduzida Entraram Carroussel: 1 
Total Clientes Crianças Entraram Carroussel: 2 
Total Clientes Publico Geral Entraram Carroussel: 2 

|---------------------------------------------------------| 
|---------------------------------------------------------| 
|----------- Clientes Entraram na Feira ------------------| 
|---------------------------------------------------------| 
|---------------------------------------------------------| 

Total Clientes Entraram Feira: 59 
Total Clientes Mobilidade Reduzida Entraram Feira: 8 
Total Clientes Crianças Entraram Feira: 10 
Total Clientes Publico Geral Entraram Feira: 41 

|--------------------------------------------------------------| 
|--------------------------------------------------------------| 
|----------- Clientes Entraram na Fila do Bar -----------------| 
|--------------------------------------------------------------| 
|--------------------------------------------------------------| 

Total Clientes Entraram Fila Bar: 6 
Total Clientes Mobilidade Reduzida Entraram Fila Bar: 1 
Total Clientes Crianças Entraram Fila Bar: 2 
Total Clientes Publico Geral Entraram Fila Bar: 3 

|--------------------------------------------------------------------| 
|--------------------------------------------------------------------| 
|-------- Clientes Entraram na Fila do Montanha Russa ---------------| 
|--------------------------------------------------------------------| 
|--------------------------------------------------------------------| 

Total Clientes Entraram Fila Montanha Russa: 8 
Total Clientes Crianças Entraram Fila Montanha Russa: 2 
Total Clientes Publico Geral Entraram Fila Montanha Russa: 6 

|------------------------------------------------------------------| 
|------------------------------------------------------------------| 
|----------- Clientes Entraram na Fila da Carroussel---------------| 
|------------------------------------------------------------------| 
|------------------------------------------------------------------| 

Total Clientes Entraram Fila Carroussel: 15 
Total Clientes Mobilidade Reduzida Entraram Fila Carroussel: 3 
Total Clientes Crianças Entraram Fila Carroussel: 2 
Total Clientes Publico Geral Entraram Fila Carroussel: 10 

|-----------------------------------------------------------------------| 
|-----------------------------------------------------------------------| 
|----------- Clientes Entraram na Fila das Bilheteiras -----------------| 
|-----------------------------------------------------------------------| 
|-----------------------------------------------------------------------| 

Total Clientes Entraram Fila Bilheteiras: 59 
Total Clientes Mobilidade Reduzida Entraram Fila Bilheteiras: 8 
Total Clientes Crianças Entraram Fila Bilheteiras: 10 
Total Clientes Publico Geral Entraram Fila Bilheteiras: 41 

|----------------------------------------------------------------| 
|----------------------------------------------------------------| 
|----------- Clientes Desistiram da Fila do Bar -----------------| 
|----------------------------------------------------------------| 
|----------------------------------------------------------------| 

Total Clientes Desistiram Fila Bar: 0 
Total Clientes Mobilidade Reduzida Desistiram Fila Bar: 0 
Total Clientes Crianças Desistiram Fila Bar: 0 
Total Clientes Publico Geral Desistiram Fila Bar: 0 

|----------------------------------------------------------------------| 
|----------------------------------------------------------------------| 
|--------- Clientes Desistiram da Fila do Montanha Russa --------------| 
|----------------------------------------------------------------------| 
|----------------------------------------------------------------------| 

Total Clientes Desistiram Fila Montanha Russa: 6 
Total Clientes Crianças Desistiram Fila Montanha Russa: 1 
Total Clientes Publico Geral Desistiram Fila Montanha Russa: 5 

|--------------------------------------------------------------------| 
|--------------------------------------------------------------------| 
|----------- Clientes Desistiram da Fila da Carroussel---------------| 
|--------------------------------------------------------------------| 
|--------------------------------------------------------------------| 

Total Clientes Desistiram Fila Carroussel: 10 
Total Clientes Mobilidade Reduzida Desistiram Fila Carroussel: 2 
Total Clientes Crianças Desistiram Fila Carroussel: 0 
Total Clientes Publico Geral Desistiram Fila Carroussel: 8 

|-------------------------------------------------------------------------| 
|-------------------------------------------------------------------------| 
|----------- Clientes Desistiram da Fila das Bilheteiras -----------------| 
|-------------------------------------------------------------------------| 
|-------------------------------------------------------------------------| 

Total Clientes Desistiram Fila Bilheteiras: 0 
Total Clientes Mobilidade Reduzida Desistiram Fila Bilheteiras: 0 
Total Clientes Crianças Desistiram Fila Bilheteiras: 0 
Total Clientes Publico Geral Desistiram Fila Bilheteiras: 0 

|-------------------------------------------------------------------------| 
|-------------------------------------------------------------------------| 
|---------------------------- Tempos Medios ------------------------------| 
|-------------------------------------------------------------------------| 
|-------------------------------------------------------------------------| 

Tempo Medio Antes Ser Atendido Bar: 0:0:1 
Tempo Medio Antes Andar Montanha Russa: 0:1:27 
Tempo Medio Antes Entrar Carroussel: 0:1:19 
Tempo Medio Antes Entrar Feira: 0:0:1 
Tempo Medio Antes Desistir Fila Bar: 0:0:0 
Tempo Medio Antes Desistir Fila Montanha Russa: 0:2:3 
Tempo Medio Antes Desistir Fila Carroussel: 0:1:54 
Tempo Medio Antes Desistir Fila Bilheteiras: 0:0:0 
Tempo Medio Estadia Feira: 0:1:3 
|-------------------------------------------------------------------------| 
|-------------------------------------------------------------------------| 
|--------------------------- Tempos Maximos ------------------------------| 
|-------------------------------------------------------------------------| 
|-------------------------------------------------------------------------| 

Tempo Maximo Antes Ser Atendido Bar: 0:0:1 
Tempo Maximo Antes Andar Montanha Russa: 0:2:53 
Tempo Maximo Antes Entrar Carroussel: 0:3:43 
Tempo Maximo Antes Entrar Feira: 0:0:1 
Tempo Maximo Antes Desistir Fila Bar: 0:0:0 
Tempo Maximo Antes Desistir Fila Montanha Russa: 0:2:50 
Tempo Maximo Antes Desistir Fila Carroussel: 0:2:46 
Tempo Maximo Antes Desistir Fila Bilheteiras: 0:0:0 

*Estatisticas Terminadas* 

