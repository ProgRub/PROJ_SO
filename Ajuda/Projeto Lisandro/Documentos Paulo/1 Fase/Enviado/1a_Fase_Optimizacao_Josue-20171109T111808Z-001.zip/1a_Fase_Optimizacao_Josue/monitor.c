#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define REGISTOS "registos.txt"

//Declaracao e Inicializacao de Variaveis de Teste a Escrever no Ficheiro:
int Total_Clientes=5;
int Total_Clientes_Atendidos=2;
int Total_Clientes_Desistentes=3;


//Funcao Para Escrever Outputs no Ficheiro:
void Escreve_Ficheiros(char *filename)
{
	FILE *fp;
	fp=fopen(filename,"w");

	fprintf(fp, "Estatisticas: \n");
	fprintf(fp, "Total Clientes: %d \n", Total_Clientes);
	fprintf(fp, "Total Clientes Atendidos: %d \n", Total_Clientes_Atendidos);
	fprintf(fp, "Total Clientes Desistentes: %d \n", Total_Clientes_Desistentes);

	fclose(fp);
}

//Funcao Para Escrever os Outputs no Ecra:
void Escreve_Outputs_Ecra(char *filename)
{
	system("clear");
	printf("Estatisticas Escritas no Ficheiro: %s\n", filename);
	printf("Total de Clientes: %i\n", Total_Clientes);
	printf("Total de Clientes Atendidos: %i\n", Total_Clientes_Atendidos);
	printf("Total de Clientes Desistentes: %i\n", Total_Clientes_Desistentes);
}



int main(int argc, char *argv[])
{
	// argv[1]=Argumento Apos Escrever ./monitor na Consola | Utilizador Pode Escolher o Nome a Atribuir ao Ficheiro
	//Escreve_Ficheiros(argv[1]); 
	Escreve_Ficheiros(REGISTOS); 
	//Escreve_Outputs_Ecra(argv[1]);
	Escreve_Outputs_Ecra(REGISTOS);

	return 0;
}

