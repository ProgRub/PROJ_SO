#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Declaracao e Inicializacao a 0 das Variaveis que vao Guardar os Valores das Variaveis Lidas do Ficheiro de Configuracao:
int Tempo_Medio_Chegadas=0;
int Tempo_Simulacao=0;
int Probabilidade_Desistencia=0;

int Tamanho_Maximo_Bar = 0;
int Tamanho_Maximo_MontanhaRussaGrande = 0;
int Tamanho_Maximo_MontanhaRussaPequena = 0;
int Tamanho_Maximo_Feira = 0;

int Tempo_Maximo_Espera_Filas = 0;
int Percentagem_Ser_Cliente_Crianca = 0;
int Percentagem_Ser_Cliente_Idoso = 0;


//Funcao Para Ler do Ficheiro Config:
void Ler_Ficheiro_Config()
{
	//Declaracao e Inicializacao de Variaveis Auxiliares da Funcao
	char Le_Linha[100];
	int Valor_Variavel_Lida;
	char Nome_Variavel_Lida[100];

	char Var1[]="Tempo_Medio_Chegadas";
	char Var2[]="Tempo_Simulacao";
	char Var3[]="Probabilidade_Desistencia";
	char Var4[] = "Tamanho_Maximo_Bar";
	char Var5[] = "Tamanho_Maximo_MontanhaRussaPequena";
	char Var6[] = "Tamanho_Maximo_MontanhaRussaGrande";
	char Var7[] = "Tamanho_Maximo_Feira";
	char Var8[] = "Tempo_Maximo_Espera_Filas";
	char Var9[] = "Percentagem_Ser_Cliente_Crianca";
	char Var10[] = "Percentagem_Ser_Cliente_Idoso";

	static int Parametros_Lidos[10];
	//------------------------------------------------------------

	FILE *fp;
	fp=fopen("config.conf","r"); //Vai Abrir o Ficheiro Config.conf
	if(fp!=NULL)
	{
		//Ciclo de Leitura:
		while(fgets(Le_Linha,100,fp)!=NULL)
		{
			/* %s= Nome da Variavel | %i= Valor da Variavel */
			sscanf(Le_Linha, "%s = %i", Nome_Variavel_Lida, &Valor_Variavel_Lida);
			
			if(strcmp(Nome_Variavel_Lida,Var1)==0)
			{
				Tempo_Medio_Chegadas=Valor_Variavel_Lida;
				printf ("%s = %i\n", Nome_Variavel_Lida, Tempo_Medio_Chegadas);
			}

			else if(strcmp(Nome_Variavel_Lida,Var2)==0)
			{
				Tempo_Simulacao=Valor_Variavel_Lida;
				printf ("%s = %i\n", Nome_Variavel_Lida, Tempo_Simulacao);
			}

			else if(strcmp(Nome_Variavel_Lida,Var3)==0)
			{
				Probabilidade_Desistencia=Valor_Variavel_Lida;
				printf ("%s = %i\n", Nome_Variavel_Lida, Probabilidade_Desistencia);
			}
			else if (strcmp(Nome_Variavel_Lida, Var4) == 0)
			{
				Tamanho_Maximo_Bar = Valor_Variavel_Lida;
				printf ("%s = %i\n", Nome_Variavel_Lida, Tamanho_Maximo_Bar);
			}
			else if (strcmp(Nome_Variavel_Lida, Var5) == 0)
			{
				Tamanho_Maximo_MontanhaRussaPequena = Valor_Variavel_Lida;
				printf ("%s = %i\n", Nome_Variavel_Lida, Tamanho_Maximo_MontanhaRussaPequena);
			}
			else if (strcmp(Nome_Variavel_Lida, Var6) == 0)
			{
				Tamanho_Maximo_MontanhaRussaGrande = Valor_Variavel_Lida;
				printf ("%s = %i\n", Nome_Variavel_Lida, Tamanho_Maximo_MontanhaRussaGrande);
			}
			else if (strcmp(Nome_Variavel_Lida, Var7) == 0)
			{
				Tamanho_Maximo_Feira = Valor_Variavel_Lida;
				printf ("%s = %i\n", Nome_Variavel_Lida, Tamanho_Maximo_Feira);
			}
			else if (strcmp(Nome_Variavel_Lida, Var8) == 0)
			{
				Tempo_Maximo_Espera_Filas= Valor_Variavel_Lida;
				printf ("%s = %i\n", Nome_Variavel_Lida, Tempo_Maximo_Espera_Filas);
			}
			else if (strcmp(Nome_Variavel_Lida, Var9) == 0)
			{
				Percentagem_Ser_Cliente_Crianca = Valor_Variavel_Lida;
				printf ("%s = %i\n", Nome_Variavel_Lida, Percentagem_Ser_Cliente_Crianca);
			}
			else if (strcmp(Nome_Variavel_Lida, Var10) == 0)
			{
				Percentagem_Ser_Cliente_Idoso = Valor_Variavel_Lida;
				printf ("%s = %i\n", Nome_Variavel_Lida, Percentagem_Ser_Cliente_Idoso);
			}
			/* Strcmp Tem Valor 0  se [Elemento1]=[Elemento2] */
		}
		fclose(fp);
	}

	else
	{
		printf("Erro Abertura Ficheiro");
	}

}

//Funcao que Mostra no Ecra as Variaveis e os Seus Valores Que Foram Lidos do Ficheiro Config.conf
void Escreve_Configuracoes()
{
	system("clear");
	printf("Parametros Lidos: \n");
	printf("Tempo Medio Chegadas: %i\n", Tempo_Medio_Chegadas);
	printf("Tempo Simulacao: %i\n", Tempo_Simulacao);

}


int main(int argc, char *argv[])
{
	Ler_Ficheiro_Config(); 
	Escreve_Configuracoes();

	return 0;
}
