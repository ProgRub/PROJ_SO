O utilizador deve executar o comando "make" no terminal na diretoria do projeto para serem criados os execut�veis.
Para come�ar a simula��o o utilizador deve abrir dois terminais.
Para n�o dar erro na socket � necess�rio executar primeiro o simulador com o comando "./Simulador" num dos terminais.
Depois no outro terminal executar o monitor com o comando "./Monitor".
Escolher a op��o para iniciar a simula��o no monitor e depois pressionar space + enter no simulador.
Depois pressionar as op��es 3 e 4 para ver os eventos em tempo real e as estat�sticas.
Quando terminar a simula��o deve sair do monitor pressionando a op��o 2.

