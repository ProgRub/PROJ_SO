│                        Estatisticas                          │

┌──────────────────────────────────────────────────────────────┐
│                Clientes Atendidos na Loja                    │ 
└──────────────────────────────────────────────────────────────┘

* Total Clientes Atendidos: 67 
* Total Clientes Idosos Atendidos: 34 
* Total Clientes Adultos Atendidos: 33 

┌──────────────────────────────────────────────────────────────┐
│                Clientes Entraram na Fila da Loja             │ 
└──────────────────────────────────────────────────────────────┘

* Total Clientes Entraram Fila: 74 
* Total Clientes Idosos Entraram Fila: 35 
* Total Clientes Adultos Entraram Fila: 39 

┌──────────────────────────────────────────────────────────────┐
│                Clientes Desistiram da Fila da Loja           │ 
└──────────────────────────────────────────────────────────────┘

* Total Clientes Desistiram da Fila: 6 
* Total Clientes Idosos Desistiram da Fila: 1 
* Total Clientes Adultos Desistiram da Fila: 5 

┌──────────────────────────────────────────────────────────────┐
│                     Vendas de Produtos                       │ 
└──────────────────────────────────────────────────────────────┘

* Total de Vendas Produto A: 27 
* Total de Vendas Produto B: 18 
* Total de Vendas Produto C: 22 


Dados Impressos Terminados.

