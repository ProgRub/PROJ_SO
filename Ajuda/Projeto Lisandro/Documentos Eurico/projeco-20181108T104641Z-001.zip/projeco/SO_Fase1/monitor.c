#include "util.h"

void escrita()
{
	FILE* logs;
	
	logs = fopen("Logs.txt", "a");
	
	if(logs == NULL){
			printf("ERRO AO CRIAR FICHEIRO");
	}
	else
	{
		fprintf(logs, "---SIMULAÇÃO INICIADA---\n");
		fprintf(logs, "TEMPO_ESPERA:30\n");
		fprintf(logs, "TEMPO_DISCO:40\n");
		fprintf(logs, "CAPACIDADE_FILA:20\n");
		fprintf(logs, "CAPACIDADE_SALA:10\n");
		fprintf(logs, "PROB_DESISTE_FILA:100\n");
		fprintf(logs, "---SIMULAÇÃO TERMINADA---\n");
	}
	
	fclose(logs);
}

int main()
{
	escrita();
	printf("Ficheiro Logs.txt criado com exito!\n");
	
	return 0;
	
}