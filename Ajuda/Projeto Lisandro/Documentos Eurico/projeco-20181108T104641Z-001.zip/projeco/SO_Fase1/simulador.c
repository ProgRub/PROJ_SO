// variaveis globais
#include "util.h"
//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>


int numCliente;
int tempoEspera, tempoDisco, tempoSimulacao, capacidadeFila, capacidadeSala, probDesisteEspera;

//função que le ficheiro
void leitura()
{
	FILE* config;
	
	config = fopen("configSim.txt", "r");
	
	if(config != NULL) {
		char linha[50];
		char* valor;
		while(fgets(linha, sizeof(linha), config) != NULL) {
			valor = strtok(linha, ":");
			if(strcmp(valor, "TEMPO_ESPERA") == 0) {
				valor = strtok(NULL, ":");
				tempoEspera = atoi(valor);
			}
			if(strcmp(valor, "TEMPO_SIMULACAO") == 0) {
				valor = strtok(NULL, ":");
				tempoSimulacao = atoi(valor);
			}
			if(strcmp(valor, "TEMPO_DISCO") == 0) {
				valor = strtok(NULL, ":");
				tempoDisco = atoi(valor);
			}
			if(strcmp(valor, "CAPACIDADE_FILA") == 0) {
				valor = strtok(NULL, ":");
				capacidadeFila = atoi(valor);
			}
			if(strcmp(valor, "CAPACIDADE_SALA") == 0) {
				valor = strtok(NULL, ":");
				capacidadeSala = atoi(valor);
			}
			if(strcmp(valor, "PROB_DESISTE_FILA") == 0) {
				valor = strtok(NULL, ":");
				probDesisteEspera = atoi(valor);
			}
			
		}
	} else {
		printf("ERRO AO ABRIR FICHEIRO\n");
	}
	fclose(config);
	
}

int main()
{
	leitura();
	printf("O tempo de espera e': %d\n",tempoEspera);
	printf("O tempo de simulação e': %d\n",tempoSimulacao);
	printf("O tempo de disco e': %d\n",tempoDisco);
	printf("A capacidade da fila e' %d\n",capacidadeFila);
	printf("A capacidade da sala e': %d\n",capacidadeSala);
	printf("A probablidade de desistencia da fila e': %d\n",probDesisteEspera);
	return 0;
}
