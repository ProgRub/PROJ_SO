#include "unix.h"

//criação do socket
int socketfd, newsockfd, servlen;
struct sockaddr_un serv_addr;

void simuladorSocket()
{
	//linha para verificar se o socket foi bem criado
	if((socketfd = socket(AF_UNIX, SOCK_STREAM, 0)) == -1)
	{
		perror("Erro socket simulador nao criado");
	}
	
	unlink(UNIXSTR_PATH); //elimina ficheiro ou socket preexisente
	bzero((*char)&end_serv, sizeof(end_serv));
	end_serv.sun_family = AF_UNIX;
	strcpy(end_serv.sun_path, SOCKET_PATH);
	msglength = strlen(end_serv.sun_path) + sizeof(end_serv.sun_family);
	
	if(connect(socketfd,(struct sockaddr*)&serv_addr, msglength)<0)
	{
		perror("Simulador não consegue ligar");
		exit(1);
	}
	else
	{
		printf("Connected!"\n);
	}
	
}