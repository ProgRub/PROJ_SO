// variaveis globais
#include "util.h"
//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h>


int numCliente;
int tempoEspera, tempoDisco, tempoSimulacao, capacidadeFila, capacidadeSala, probDesisteEspera;
//variaveis dos sockets
int socketfd, newsockfd, servlen;
struct sockaddr_un serv_addr;

//função que le ficheiro
void leitura()
{
	FILE* config;
	
	config = fopen("configSim.txt", "r");
	
	if(config != NULL) {
		char linha[50];
		char* valor;
		while(fgets(linha, sizeof(linha), config) != NULL) {
			valor = strtok(linha, ":");
			if(strcmp(valor, "TEMPO_ESPERA") == 0) {
				valor = strtok(NULL, ":");
				tempoEspera = atoi(valor);
			}
			if(strcmp(valor, "TEMPO_SIMULACAO") == 0) {
				valor = strtok(NULL, ":");
				tempoSimulacao = atoi(valor);
			}
			if(strcmp(valor, "TEMPO_DISCO") == 0) {
				valor = strtok(NULL, ":");
				tempoDisco = atoi(valor);
			}
			if(strcmp(valor, "CAPACIDADE_FILA") == 0) {
				valor = strtok(NULL, ":");
				capacidadeFila = atoi(valor);
			}
			if(strcmp(valor, "CAPACIDADE_SALA") == 0) {
				valor = strtok(NULL, ":");
				capacidadeSala = atoi(valor);
			}
			if(strcmp(valor, "PROB_DESISTE_FILA") == 0) {
				valor = strtok(NULL, ":");
				probDesisteEspera = atoi(valor);
			}
			
		}
	} else {
		printf("ERRO AO ABRIR FICHEIRO\n");
	}
	fclose(config);
	
}

void simuladorSocket()
{
	//linha para verificar se o socket foi bem criado
	if((socketfd = socket(AF_UNIX, SOCK_STREAM, 0)) == -1)
	{
		perror("Erro socket simulador nao criado");
	}
	
	unlink(UNIXSTR_PATH); //elimina ficheiro ou socket preexisente
	bzero((*char)&end_serv, sizeof(end_serv));
	end_serv.sun_family = AF_UNIX;
	strcpy(end_serv.sun_path, SOCKET_PATH);
	msglength = strlen(end_serv.sun_path) + sizeof(end_serv.sun_family);
	
	if(connect(socketfd,(struct sockaddr*)&serv_addr, msglength)<0)
	{
		perror("Simulador não consegue ligar");
		exit(1);
	}
	else
	{
		printf("Connected!"\n);
	}
	
}

int main()
{
	leitura();
	printf("O tempo de espera e': %d\n",tempoEspera);
	printf("O tempo de simulação e': %d\n",tempoSimulacao);
	printf("O tempo de disco e': %d\n",tempoDisco);
	printf("A capacidade da fila e' %d\n",capacidadeFila);
	printf("A capacidade da sala e': %d\n",capacidadeSala);
	printf("A probablidade de desistencia da fila e': %d\n",probDesisteEspera);
	
	simuladorSocket();
	
	return 0;
	
}
