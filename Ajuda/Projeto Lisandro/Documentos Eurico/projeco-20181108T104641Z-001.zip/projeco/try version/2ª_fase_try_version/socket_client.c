#include "unix.h"

int sockfd, clilen, newsockfd, servlen;
struct sockaddr_un cli_addr, serv_addr;

void criarSocket()
{
	if((sockfd = socket(AF_UNIX, SOCK_STREAM, 0)) == -1)
	{
		perror("Erro ao abrir socket\n");
		exit(1);
	}

	serv_add.sun_family = AF_UNIX;
	stpcpy(serv_addr.sun_path, SOCKET_PATH);
	msglength = strlen(serv_addr.sun_path) + sizeof(serv_addr.sun_family);
	unlink(SOCKET_PATH);

	if(bind(sockfd, (struct sockaddr *)&serv_addr, servlen)<0)
	{
		perror("Monitor não conseguio ligar ao socket\n");
		exit(1);
	}

	if(listen(sockfd, 1) == -1)
	{
		perror("Erro no lisen monitor");
	}

	newsockfd = accept(sockfd,(struct sockaddr *)&cli_addr, &clilen);

	if(newsockfd < 0)
	{
		perror ("Servidor nao aceite\n");
		exit(1);
	}

}