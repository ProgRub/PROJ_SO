#include "util.h"

//variaveis dos sockets
int sockfd, clilen, newsockfd, servlen;
struct sockaddr_un cli_addr, serv_addr;

void escrita()
{
	FILE* logs;
	
	logs = fopen("Logs.txt", "a");
	
	if(logs == NULL){
			printf("ERRO AO CRIAR FICHEIRO");
	}
	else
	{
		fprintf(logs, "---SIMULAÇÃO INICIADA---\n");
		fprintf(logs, "TEMPO_ESPERA:30\n");
		fprintf(logs, "TEMPO_DISCO:40\n");
		fprintf(logs, "CAPACIDADE_FILA:20\n");
		fprintf(logs, "CAPACIDADE_SALA:10\n");
		fprintf(logs, "PROB_DESISTE_FILA:100\n");
		fprintf(logs, "---SIMULAÇÃO TERMINADA---\n");
	}
	
	fclose(logs);
}

void criarSocket()
{
	if((sockfd = socket(AF_UNIX, SOCK_STREAM, 0)) == -1)
	{
		perror("Erro ao abrir socket\n");
		exit(1);
	}

	serv_add.sun_family = AF_UNIX;
	stpcpy(serv_addr.sun_path, SOCKET_PATH);
	msglength = strlen(serv_addr.sun_path) + sizeof(serv_addr.sun_family);
	unlink(SOCKET_PATH);

	if(bind(sockfd, (struct sockaddr *)&serv_addr, servlen)<0)
	{
		perror("Monitor não conseguio ligar ao socket\n");
		exit(1);
	}

	if(listen(sockfd, 1) == -1)
	{
		perror("Erro no lisen monitor");
	}

	newsockfd = accept(sockfd,(struct sockaddr *)&cli_addr, &clilen);

	if(newsockfd < 0)
	{
		perror ("Servidor nao aceite\n");
		exit(1);
	}

}

int main()
{
	escrita();
	printf("Ficheiro Logs.txt criado com exito!\n");
	
	return 0;
	
}