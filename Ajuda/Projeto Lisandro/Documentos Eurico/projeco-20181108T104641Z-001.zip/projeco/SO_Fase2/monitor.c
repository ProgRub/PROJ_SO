#include "util.h"

//varáveis dos sockets
int socketfd, clilen, newsocketfd, servlen, msglength;
int pararsimulacao = 0;
struct sockaddr_un cli_addr, serv_addr;

void escrita()
{
	FILE* logs;
	
	logs = fopen("Logs.txt", "a");
	
	if(logs == NULL){
			printf("ERRO AO CRIAR FICHEIRO");
	}
	else
	{
		fprintf(logs, "---SIMULAÇÃO INICIADA---\n");
		fprintf(logs, "TEMPO_ESPERA:30\n");
		fprintf(logs, "TEMPO_DISCO:40\n");
		fprintf(logs, "CAPACIDADE_FILA:20\n");
		fprintf(logs, "CAPACIDADE_SALA:10\n");
		fprintf(logs, "PROB_DESISTE_FILA:100\n");
		fprintf(logs, "---SIMULAÇÃO TERMINADA---\n");
	
		while(1)
		{
			char buff[3];
			recv(newsocketfd, buff, sizeof(char)*6, 0);
			if(buff[0] == 'A')
			{
				printf("Recebeu mensagem\n");
				fprintf(logs, "sdfsd");
				break;
			}
			else
			{
				printf("Nao recebeu mensagem\n");	
				fprintf(logs, "deu merda");	
				break;	
			}
		}
	}
	
	fclose(logs);
}

void criarSocket()
{
	if((socketfd = socket(AF_UNIX, SOCK_STREAM, 0)) == -1)
	{
		perror("Erro ao abrir socket\n");
		exit(1);
	}

	serv_addr.sun_family = AF_UNIX;
	strcpy(serv_addr.sun_path, SOCKET_PATH);
	msglength = strlen(serv_addr.sun_path) + sizeof(serv_addr.sun_family);
	unlink(serv_addr.sun_path);

	if(bind(socketfd, (struct sockaddr *)&serv_addr, msglength)<0)
	{
		perror("Monitor não conseguio ligar ao socket\n");
		exit(1);
	}

	if(listen(socketfd, 1) == -1)
	{
		perror("Erro no lisen monitor");
	}

	newsocketfd = accept(socketfd,(struct sockaddr *)&cli_addr, &clilen);

	if(newsocketfd < 0)
	{
		perror ("Servidor nao aceite\n");
		exit(1);
	}

}

void *lerSocket()
{
	char aux[80];
	char msg[80];
	strcpy(aux, "\nSimulacao terminou\n");
	int ret = strcmp(aux, msg);
	read(newsocketfd, msg, sizeof(msg));

	if(ret == 0)
	{
		pararsimulacao = 1;
		return NULL;
	}
	
	printf("%s", msg);
	return NULL;
}

int main()
{
	
	printf("Ficheiro Logs.txt criado com exito!\n");
	
	criarSocket();
	lerSocket();
	escrita();

	//char msg[80];
	//while(pararsimulacao == 0)
	//{
	//	pthread_t lerSocket;
	//	pthread_create(&lerSocket, NULL, &lerSocket, NULL);
	//	pthread_join(lerSocket, NULL);
	//}
	

	close(socketfd);	

	return 0;
	
}
