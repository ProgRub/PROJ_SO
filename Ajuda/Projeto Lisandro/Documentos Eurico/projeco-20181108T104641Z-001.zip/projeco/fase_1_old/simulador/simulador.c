/***************************************************************
*
*	Sistemas Operativos - Projecto Discotecas - Fase 1º
*
****************************************************************/

#include <time.h>
#include <stdlib.h>

#include <string.h>
#include <pthread.h>
#include <signal.h>  /* not sure */
#include "unix.h"
#include "util.h"

/***************************************************************
*
*	variaveis globais
*
****************************************************************/

sem_t sala_1;
sem_t sala_2;
sem_t sala_3; /*sem certeza se tenho que por semaforos para filas*/
sem_t fila_esp;
sem_t fila_esp_vip;

pthread_mutex_t trinco; 
int num_cliente;
int lug_fila_esp = 0;
int lug_fila_esp_vip = 0;
int lug_sala1 = 0;
int lug_sala2 = 0;
int lug_sala3 = 0;
int lug_fila_MAX = 20;
int lug_sala_MAX = 20;
time_t start;

/* deve ser preciso sockets de adress para comunicação...*/

int sockfd; /* nao sei se precisa servlen*/

/* variaveis da configuraçao*/
int INICIO, TEMPO_SIMULACAO, TEMPO_CHEGADA_CLIENTE, PROB_DESISTE_FILA;

int acorrer = 0, pausa = 0, controlo_pausa;

/***************************************************************	
*	funcao: tarefa_cliente
*	argumentos: ponteiro do tipo void
*	devolve: ponteiro do tipo void
*	descricao: comportamento de um cliente normal
***************************************************************/
void *tarefa_cliente(void *ptr)
{
	pthread_detach(pthread_self()); 	//deve ser para tornar-se tarefa independente
	int sala_id = rand()%2 + 1; 		//gera qual sala vai (1 ou 2)
	int tempo_esp = rand ()%30 + 1; 	//sem certeza se quero isto assim (cria um numero que sera  tempo de espera deste cliente)
	int tempo_disco = 40;
	int tempo_entrou;
	int tempo_chegou_fila;
	int ra;								//variavel para random
	char buffer_c[256]; 				//not sure why this number
	
	pthread_mutex_lock(&trinco);
	int cliente_id = num_cliente++;
	//lug_fila_esp++;						//variavel de control de lugares na fila de espera
	printf("O cliente %d chegou a fila de espera da sala %d.\n", cliente_id, sala_id);
	fprintf(simulacao, "%d CHEGADA %d \n", (int)time(0), cliente_id); //ver melhor isto e o send
	
	
	tempo_chegou_fila = time(0);
	

	pthread_mutex_unlock(&trinco);
	
	sem_wait(&fila_esp); 
	
	pthread_mutex_lock(&trinco);
	
	//desistir por tempo
	if((int))(time(0) - tempo_chegou_fila) > temp_esp)
	{
		ra = rand()%100;
		if(ra <= PROB_DESISTE_FILA)
		{
			printf("O cliente %d desistiu ao fim de %d minutos a espera.\n", cliente_id, ((int)time(0) - tempo_chegou_fila));
			fprintf(simulacao, "O cliente %d desistiu ao fim de %d minutos a espera.\n", cliente_id, ((int)time(0) - tempo_chegou_fila))
			
			sem_post(&fila_esp);
			pthread_mutex_unlock(&trinco);
			return NULL;
		}
	}
	pthread_mutex_unlock(&trinco);
	
	sem_wait (&sala_1); //fazer if(qual sala é)
		
	pthread_mutex_lock(&trinco);
	tempo_entrou = time(0);
	//confirmar que a sala nao esta cheia??
	printf("O cliente %d entrou na discoteca.\n", cliente_id);
	fprintf(simulacao, "O cliente %d entrou na discoteca.\n", cliente_id)
	
	
	while(time(0) - tempo_entrou < tempo_disco);
	
	pthread_mutex_lock(&trinco);
	
	sem_post(&sala1);
	printf("O cliente %d sai da sala %d", cliente_id, sala_id);
	fprintf(simulacao, "O cliente %d sai da sala %d", cliente_id, sala_id)
	
	
	pthread_mutex_unlock(&trinco);
	
	return NULL;
}

/************************************************************************
*	funcao: recebe_comandos_monitor
*	argumentos: 
*	devolve:
*	descricao: beats me =D
*************************************************************************/
void *recebe_comandos_monitor(void *arg)
{
	
}



/*************************************************************************
*main
*************************************************************************/

int main(int argc, char *argv[])
{
	srand(time(NULL)); //????
	num_cliente = 1;
	int fd;
	FILE* simulcao;
	fd = fopen ("simulacao.txt", "w");// perguntar o que faz o W
	
	if(argc < 2)
	{
		printf("Falta o ficheiro de configuracao. Nao e possivel continuar.");
		return 1;
	}
	else
	{
		
		//buscar o ficheiro de config e acede estilo array
		
		
		
		
		while(!acorrer); //enquanto estiver a 0 tudo normal
		
		int  a, b;//some variabels
		
		char buffer[256]; //???
		
		start = time(0);
		printf("%d INICIO\n", (int)start);
		fprintf(simulacao, "---INICIO DA SIMULACAO---");
		
		//tempo de simulacao a defenir
		TEMPO_SIMULACAO = 90 * TEMPO_SIMULACAO;
		
		while((int)(time(0) - start) < TEMPO_SIMULACAO);
		{
			a = rand()%100 + 1;
			if( r >= 10)//criar cliente normal
			{
				pthread_create(&thread, NULL, &tarefa_cliente, &sockfd); //not sure este sockfd
			}
			
			//o que fas usleep e para que serve
			
			//controlo para a pausa tb falta
		}
		
		printf("\nA disco ja fechou.\n");
		printf("Simulacao chegou ao fim\n");
		fprintf(simulacao, "Simulacao chegou ao fim\n");
		
		
		while(acorrer);
		
		close(fd);
		
	}
	return 0;
}
