#include <pthread.h>
#include <string.h>
#include "unix.h"
#include "util.h"

//apontador ara o ficheiro onde será escrito o simulacao da simulacao
FILE *simulacao;//talves ter isto dentro do main

//variaveis globais
int num_cliente, lug_sala1, lug_sala2, lug_sala3;
int lug_fila_esp, lug_fila_esp_vip, desistencias;

//variaveis de controlo de execucao
int acorrer = 0, pausa = 0;
/*****************************************************************
*
*	funcao que devolve as informacoes para estatisticas da disco
*
******************************************************************/
void mostra_estatistica()
{
	if(acorrer && !pausa)
	{
		printf(" 1. Estado actual: Simulacao a decorrer.\n");
		fprintf(simulacao, " 1. Estado actual: Simulacao a decorrer.\n");
	}
	else
	{
		if(pausa)
		{
			printf(" 1. Estado actual: Simulacao em pausa.\n");
			fprintf(simulacao, " 1. Estado actual: Simulacao em pausa.\n");
		}
		else
		{
			printf(" 1. Estado actual: Simulacao Terminada\n");
			fprintf(simulacao, " 1. Estado actual: Simulacao Terminada\n");
			
		}
	}
	printf(" 2. Tamanho actual da fila de espera da Disco: %d\n", lug_fila_esp + lug_fila_esp_vip);
	fprintf(simulacao, " 2. Tamanho actual da fila de espera da Disco: %d\n", lug_fila_esp + lug_fila_esp_vip);
	
	printf(" 3. Número de Clientes ja atendidos: %d", num_cliente - desistencias);
	fprintf(simulacao, " 3. Número de Clientes ja atendidos: %d", num_cliente - desistencias);
	
	printf(" 4. Desistencias da Fila de Espera: %d", desistencias);
	fprintf(simulacao, " 4. Desistencias da Fila de Espera: %d", desistencias);
	//saber se por mais estatisticas e quais
}



/***********************************************************
*
*	main
*
************************************************************/
int main(int argc, char *argv[])
{
	//int fd; //sem certeza se é isto assim, ou simplesmente fopen como esta em baixo
	
	
	char buffer[256]; //nao parece que utilize isto
	
	//criacao da tarefa para comunicar estatisticas
	
	
	
	FILE* simulacao = fopen("simulacao.txt", "w");  //simulacao o .txt criado no simulador
	//fprintf(simulacao, "---Simulacao Iniciada---\n");
	
	//falta se calhar fazer um while para ir escrevendo ou parar enkuanto simulacao dura...
	mostra_estatistica();
	//fprintf(simulacao, "---Simulacao Terminou---\n");
	fclose(fd);
	
	return 0;
	
	
}