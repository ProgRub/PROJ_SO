// variaveis globais
#include <util.h>



int numCliente;
int tempoEspera, tempoDisco, tempoSimulacao, capacidadeFila, capacidadeSala, probDesisteEspera;

//função que le ficheiro
void leitura()
{
	FILE *config;
	
	config = fopen("configSim.txt", "r");
	
	if(configuracao != NULL) {
		char linha[50];
		char* valor;
		while(fgets(linha, sizeof(linha), config) != NULL) {
			valor = strtok(linha, ":");
			if(strcmp(valor, "TEMPO_ESPERA") == 0) {
				valor = strtok(NULL, ":");
				tempoEspera = atoi(valor);
			}
			if(strcmp(valor, "TEMPO_SIMULACAO") == 0) {
				valor = strtok(NULL, ":");
				tempoSimulacao = atoi(valor);
			}
			if(strcmp(valor, "TEMPO_DISCO") == 0) {
				valor = strtok(NULL, ":");
				tempoDisco = atoi(valor);
			}
			if(strcmp(valor, "CAPACIDADE_FILA") == 0) {
				valor = strtok(NULL, ":");
				capacidadeFila = atoi(valor);
			}
			if(strcmp(valor, "CAPACIDADE_SALA") == 0) {
				valor = strtok(NULL, ":");
				capacidadeSala = atoi(valor);
			}
			if(strcmp(valor, "PROB_DESISTE_FILA") == 0) {
				valor = strtok(NULL, ":");
				probDesisteEspera = atoi(valor);
			}
			
		}
	} else {
		printf("ERRO AO ABRIR FICHEIRO\n");
	}
	fclose(config);
	
}

int main()
{
	leitura();
	return 0;
}